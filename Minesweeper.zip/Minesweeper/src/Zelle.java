

public class Zelle {
	/*int anzahlBomben = 4;
	String bombe = "*";
	String eineBombeInUmgebung = "1";
	String zweiBombenInUmgebung = "2";*/
	
}

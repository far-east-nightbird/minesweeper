import java.util.Scanner;  // Import the Scanner class

public class Eingabe {
    static Scanner scanner = new Scanner(System.in);
    
    public static void eingabe() {
    System.out.println("Willkommen zu Minesweeper");
    System.out.println("Wenn Sie ein Feld aufdecken wollen, geben Sie A die Spalte und die Zeile ein. zB: A56");
    System.out.println("Wenn Sie ein Feld markieren wollen, in dem sich eine Bombe befindet, geben Sie M die Spalte und die Zeile ein. zB: A56");

    String mine = scanner.nextLine();  // Read user input
    //System.out.println(mine);  // Output user input
  }
  }

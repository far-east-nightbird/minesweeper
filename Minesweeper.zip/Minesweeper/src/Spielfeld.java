
import java.util.*;

public class Spielfeld {
	private String[][] spielfeld;
	private static final int zeile = 8;
	private static final int spalte = 8;
	private static final String String = null;
	
	private Random rand = new Random();
	private int anzahlBomben = 4;
	private String flagge = "!";
	private String bombe = "*";
	private String eineBombeInUmgebung = "1";
	private String zweiBombenInUmgebung = "2";
	
	public Spielfeld() {
		spielfeld = new String[zeile][spalte];
	}

	public void initiiereSpielfeld() {
		//Bomben verteilen
		for(int i = 0; i < 5; i++) {
			int z = rand.nextInt(8);
			int s = rand.nextInt(8);
			spielfeld[z][s] = "*";
		}
		
		/*for(int i = 0; i < zeile; i++) {
			for(int j = 0; j < spalte; j++) {
				spielfeld[i][j] = "  " ;*/
			}
		}
	}
	
	public void druckeZeileSpalte() {
		//Spalten
		System.out.print(" ");
		for(int i = 0; i < zeile; i++) {
			System.out.print(i + " ");
		}
		
		
		System.out.println();
	
		
		for(int i = 0; i < zeile; i++) {
			System.out.print(i);
			for(int j = 0; j < spalte; j++) {
				System.out.print(" ");
			}
			System.out.println();
		}
	}
	
	/*public String druckeZeileSpalte() {
		//Spalten
		String brett = "";
		for(int i = 0; i < zeile; i++) {
			brett = java.lang.String.valueOf(i) + " ";
		}
	
	
		
		for(int i = 0; i < zeile; i++) {
			brett = java.lang.String.valueOf(i);
			for(int j = 0; j < spalte; j++) {
				brett += spielfeld[i][j];
			}
		}
		return brett;
	}*/

	}
	


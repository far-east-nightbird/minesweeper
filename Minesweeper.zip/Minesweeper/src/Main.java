import java.util.Scanner;

public class Main {
	public Main() {
		
		
		
			}
	 public static void main(String[] args){ 
		
		 Eingabe eingabe = new Eingabe();
		 Eingabe.eingabe();
		 
		 Spielfeld spielfeld = new Spielfeld();
		 spielfeld.initiiereSpielfeld();
		 spielfeld.druckeZeileSpalte();
		 
		 
		 
	 }
	 
	 }

 